clear, clc, close all
load("VineData.mat")
load("EnvironmentalForcing.mat")
speed = 1/9;
checked = zeros(50,50);
cost = 0;
%         amt = 4;
for t = 216:1465
        [infects,infectsFound,checked] = Scouting(speed,vine,t,4,checked);
                disp(checked)

        cost = cost + 100;
        if (t-1)/24 > 10
            cost = cost + 1000;
        end
        if infectsFound == 1 && findSwitch == 0
            tFound = t;
            disp('Infection Found')
            return
        end
end
function [infects,infectsFound,checked] = Scouting(speed,vine,t,opts,checked)
    global NpX NpY
    infects = zeros(NpX,NpY);
    infectsFound = 0;
    DetectSize = (20*speed/10)^2/4*pi/5000;
    distMax = speed*3600;
    distUsed = 0;
%     if opts == 1
%         gridSize = floor(sqrt(Npnts));
%         for i = 1:gridSize:NpX
%             for j = 1:gridSize:NpY
    if opts == 2
        for a = 1:amt
            currLoc = [0,0];
            while distUsed < distMax && infectsFound ~= 1
                RandSearch = randi(NpX*NpY);
                %fprintf('day:%i (%i,%i)\n',round(t/24),vine(RandSearch).X+.5,vine(RandSearch).Y+.5)
                distUsed = distUsed + sqrt((vine(RandSearch).X - currLoc(1))^2 + (vine(RandSearch).Y - currLoc(2))^2);
                if distUsed > distMax
                    break
                end
                if vine(RandSearch).I(t) >= DetectSize
                    infects(vine(RandSearch).X+0.5,vine(RandSearch).Y+0.5) = 1;
                    infectsFound = 1;
                    return
                end
                currLoc = [vine(RandSearch).X,vine(RandSearch).Y];

            end
        end
    end

    if opts == 3
        for a = 1:amt
            corner = randi([1,4]);
            switch(corner)
                case 1
                    currLoc = [0,0];
                case 2
                    currLoc = [0,50];
                case 3 
                    currLoc = [50,0];
                case 4
                    currLoc = [50,50];
            end
            while distUsed < distMax && infectsFound ~= 1
                newrandx = randi([round(currLoc(1))-10, uptox(round(currLoc(1))+10)],"uint16");
                newrandy = randi([round(currLoc(2))-10, uptoy(round(currLoc(2))+10)],"uint16");
                while newrandy == 0 && newrandx == 0 
                newrandx = randi([round(currLoc(1))-10, uptox(round(currLoc(1))+10)],"uint16");
                newrandy = randi([round(currLoc(2))-10, uptoy(round(currLoc(2))+10)],"uint16");    
                end
                RandSearch = round(newrandx)+floor(newrandy)*50;
                %fprintf('day:%i (%i,%i)\n',round(t/24),vine(RandSearch).X+.5,vine(RandSearch).Y+.5)
                distUsed = distUsed + sqrt((vine(RandSearch).X - currLoc(1))^2 + (vine(RandSearch).Y - currLoc(2))^2);

                if distUsed > distMax
                    break
                end
                if vine(RandSearch).I(t) >= DetectSize
                    infects(vine(RandSearch).X+0.5,vine(RandSearch).Y+0.5) = 1;
                    infectsFound = 1;
                    return
                end
                currLoc = [vine(RandSearch).X,vine(RandSearch).Y];
            end
        end
    end
    if opts == 4
        t = t-215;
        currLoc = [0 (t-2)*8+.5];
        currLocInx = 1+(t-2)*8*50;
        distUsed = .5;
        adding = true; 
        numits =1;
        while distUsed<distMax
            if mod(numits,50)==1
                if adding==true
                    currLocInx = currLocInx+49;
                else
                    currLocInx = currLocInx+51;
                end
                adding = not(adding);
            end
            
            if vine(currLocInx).I(t) >= DetectSize
                infects(vine(currLocInx).X+0.5,vine(currLocInx).Y+0.5) = 1;
                infectsFound = 1;
                return
            end
            checked(vine(currLocInx).Y+0.5,vine(currLocInx).X+0.5) = 1;
            numits=numits+1;
            distUsed = distUsed+1;
            if adding == true
                currLocInx = 1+currLocInx;
            end
            if adding == false
                currLocInx = currLocInx-1;
            end
        end
    end
end
