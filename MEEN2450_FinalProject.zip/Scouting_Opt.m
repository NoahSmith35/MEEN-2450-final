clear, clc, close all

load("VineData3.mat")
load("EnvironmentalForcing.mat")

global NpX NpY Nsteps
NpX = 50;     %number of plants in the X-direction
NpY = 50;     %number of plants in the Y-direction
Nsteps = length(T); %number of time steps for integration

findSwitch = 0;
cost = 0;
loops = 50;
style = 1; % Pick scouting method | 1:Random search | 2: Modified random search | 3: grid search
minCostAll = 1000000*ones(1,loops);
optAmtAll = zeros(1,loops);
optSpdAll = zeros(1,loops);
optTFoundAll = zeros(1,loops);
optStartDay = zeros(1,loops);
start_t = 840; % Day 35
for i = 1:loops
    disp(i)
    for amt = 1:1:12
        for speed =(2/40):.05:.5
            for start_day = 25:1:45
                start_t = 24*start_day + 1;
                cost = max(1000*(start_day - 10),0);
                for t = start_t:length(tspan) 
                    if mod(t,24) == 0 && findSwitch ==0
                        [infects,infectsFound] = Scouting(speed,vine,t,style,amt);
                        cost = cost + amt*100;
                        if (t-1)/24 > 10 && mod(t,24) == 0
                            cost = cost + 1000;
                        end
                        if infectsFound == 1 && findSwitch == 0
                            tFound = t;
                            findSwitch = 1;
        %                     disp('Infection Found')
                        end
                    end
                end

                if cost<minCostAll(i)
                    minCostAll(i) = cost;
                    optAmtAll(i) = amt;
                    optSpdAll(i) = speed;
                    optTFoundAll(i) = tFound;
                    optStartDay(i) = start_day;
                end
                cost = 0;
                findSwitch = 0;
            end
        end
    end
end
% disp(optTFound/24)
meanMinCost = mean(minCostAll)
meanOptAmt = mean(optAmtAll)
meanOptSpd = mean(optSpdAll)
meanTFound = mean(optTFoundAll);
meanStartDay = mean(optStartDay)

% figure
% scatter(optAmtAll,optSpdAll)


function [infects,infectsFound] = Scouting(speed,vine,t,opts,amt,infects)
    global NpX NpY
    infects = zeros(NpX,NpY);
    infectsFound = 0;
%     DetectSize = (20*speed/10)^2/4*pi/5000;
    DetectSize = max(40*speed,2)^2/4*pi/5000;
    
    distMax = speed*3600;
    distUsed = 0;
    %% Random Search
    if opts == 1
        for a = 1:amt
            currLoc = [0,0];
            while distUsed < distMax && infectsFound ~= 1
                RandSearch = randi(NpX*NpY);
                distUsed = distUsed + sqrt((vine(RandSearch).X - currLoc(1))^2 + (vine(RandSearch).Y - currLoc(2))^2);
                if distUsed > distMax
                    break
                end
                if vine(RandSearch).I(t) >= DetectSize
                    infects(vine(RandSearch).X+0.5,vine(RandSearch).Y+0.5) = 1;
                    infectsFound = 1;
                    return
                end
                currLoc = [vine(RandSearch).X,vine(RandSearch).Y];

            end
        end
    end
    %% Modified Random Search
    if opts == 2
        for a = 1:amt
            corner = randi([1,4]);
            switch(corner)
                case 1
                    currLoc = [0,0];
                case 2
                    currLoc = [0,50];
                case 3 
                    currLoc = [50,0];
                case 4
                    currLoc = [50,50];
            end
            while distUsed < distMax && infectsFound ~= 1
                newrandx = randi([round(currLoc(1))-10, uptox(round(currLoc(1))+10)],"uint16");
                newrandy = randi([round(currLoc(2))-10, uptoy(round(currLoc(2))+10)],"uint16");
                while newrandy == 0 && newrandx == 0 
                    newrandx = randi([round(currLoc(1))-10, uptox(round(currLoc(1))+10)],"uint16");
                    newrandy = randi([round(currLoc(2))-10, uptoy(round(currLoc(2))+10)],"uint16");    
                end
                RandSearch = round(newrandx)+floor(newrandy)*50;
                distUsed = distUsed + sqrt((vine(RandSearch).X - currLoc(1))^2 + (vine(RandSearch).Y - currLoc(2))^2);

                if distUsed > distMax
                    break
                end
                if vine(RandSearch).I(t) >= DetectSize
                    infects(vine(RandSearch).X+0.5,vine(RandSearch).Y+0.5) = 1;
                    infectsFound = 1;
                    return
                end
                currLoc = [vine(RandSearch).X,vine(RandSearch).Y];
            end
        end
    end
    %% Grid Search
    if opts == 3
        t = (t-44)/2;
        currLocInx = 1+(t-2)*3*50;
        distUsed = .5;
        adding = true; 
        numits =1;
        while distUsed<distMax
            if mod(numits,50)==1
                if adding
                    currLocInx = currLocInx+49;
                else
                    currLocInx = currLocInx+51;
                end
                adding = not(adding);
            end
            
            if vine(currLocInx).I(2*t+44) >= DetectSize
                infects(vine(currLocInx).X+0.5,vine(currLocInx).Y+0.5) = 1;
                infectsFound = 1;
                return
            end
            numits=numits+1;
            distUsed = distUsed+1;
            if adding
                currLocInx = 1+currLocInx;
            else
                currLocInx = currLocInx-1;
            end
        end
    end
end

function max = uptox(int)

if int>50
   max = 50;
else
   max = int;
end

end
function max = uptoy(int)

if int>=50
   max = 49;
else
   max = int;
end

end